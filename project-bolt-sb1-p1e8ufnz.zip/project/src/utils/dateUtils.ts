// Date validation
export function isValidDate(dateStr: string): boolean {
  if (!dateStr) return false;
  const date = new Date(dateStr);
  return date instanceof Date && !isNaN(date.getTime());
}

// Parse date from any format to YYYY-MM-DD
export function parseDate(dateStr: string): string {
  if (!dateStr) return '';
  
  try {
    // Remove any extra whitespace
    dateStr = dateStr.trim();
    
    // Handle DD/MM/YYYY format
    if (dateStr.includes('/')) {
      const [day, month, year] = dateStr.split('/').map(part => part.trim());
      if (!day || !month || !year) return '';
      
      // Ensure year has 4 digits
      const fullYear = year.length === 2 ? `20${year}` : year;
      return `${fullYear}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
    }
    
    // Handle Excel date serial numbers
    if (!isNaN(Number(dateStr))) {
      const excelDate = new Date((Number(dateStr) - 25569) * 86400 * 1000);
      return excelDate.toISOString().split('T')[0];
    }
    
    // If it's already in YYYY-MM-DD format
    if (dateStr.includes('-') && isValidDate(dateStr)) {
      return dateStr;
    }
    
    return '';
  } catch (error) {
    console.error('Error parsing date:', dateStr, error);
    return '';
  }
}

// Format date to Brazilian format (DD/MM/YYYY)
export function formatDateToBR(dateStr: string): string {
  if (!dateStr) return '';
  
  try {
    // Handle YYYY-MM-DD format
    if (dateStr.includes('-')) {
      const [year, month, day] = dateStr.split('-').map(part => part.trim());
      if (!year || !month || !day) return '';
      return `${day}/${month}/${year}`;
    }
    
    return '';
  } catch (error) {
    console.error('Error formatting date to BR:', dateStr, error);
    return '';
  }
}

// Format days remaining/past
export function formatDays(days: number): string {
  const isNegative = days < 0;
  const absoluteDays = Math.abs(days);
  
  if (isNegative) {
    return `${absoluteDays} dias atrás`;
  }
  return `${absoluteDays} dias restantes`;
}

// Get color based on days remaining
export function getDaysColor(days: number): string {
  if (days < 0) return 'text-red-600';
  if (days <= 7) return 'text-orange-600';
  if (days <= 30) return 'text-yellow-600';
  return 'text-green-600';
}