import { Customer } from '../types/Customer';

interface FilterOptions {
  searchTerm: string;
  statusFilter: string;
}

export function filterCustomers(customers: Customer[], options: FilterOptions): Customer[] {
  const { searchTerm, statusFilter } = options;
  const search = searchTerm.toLowerCase();

  return customers.filter((customer) => {
    const matchesSearch = 
      customer.name.toLowerCase().includes(search) ||
      customer.whatsapp.includes(search);

    if (statusFilter === 'all') return matchesSearch;
    if (statusFilter === 'active') return matchesSearch && customer.active;
    if (statusFilter === 'inactive') return matchesSearch && !customer.active;
    
    return matchesSearch;
  });
}