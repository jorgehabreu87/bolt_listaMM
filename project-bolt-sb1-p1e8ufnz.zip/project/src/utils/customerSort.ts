import { Customer } from '../types/Customer';

export function sortCustomers(customers: Customer[], isAscending: boolean): Customer[] {
  return [...customers].sort((a, b) => {
    const nameA = a.name.toLowerCase();
    const nameB = b.name.toLowerCase();
    
    return isAscending 
      ? nameA.localeCompare(nameB)
      : nameB.localeCompare(nameA);
  });
}