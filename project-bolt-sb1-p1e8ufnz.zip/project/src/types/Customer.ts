export interface Customer {
  id: number;
  name: string;
  whatsapp: string;
  active: boolean;
  dataFinal: string;
  tempo: number; // Changed to number for days
}