import axios from 'axios';
import { Customer } from '../types/Customer';

const SPREADSHEET_ID = '1uwf5RY_BhDUQg71hOZg4bcW52V4ApQxm7bW5Rq9wqxM';
const SHEET_NAME = 'Sheet1';

export async function fetchCustomers(): Promise<Customer[]> {
  try {
    const response = await axios.get(
      `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/gviz/tq?tqx=out:json&sheet=${SHEET_NAME}`
    );

    // Extract the JSON from the response
    const jsonStr = response.data.substring(47).slice(0, -2);
    const data = JSON.parse(jsonStr);

    // Map the rows to our Customer interface
    return data.table.rows.slice(1).map((row: any, index: number) => {
      // Ensure we get all values, even if they're null/undefined
      const cells = row.c || [];
      const name = cells[0]?.v ?? '';
      const whatsapp = cells[1]?.v ?? '';
      const status = cells[2]?.v ?? false;
      const dataFinal = cells[3]?.f ?? cells[3]?.v ?? ''; // Try to get formatted value first
      const tempo = cells[4]?.v ?? 0;
      
      return {
        id: index + 1,
        name: String(name).trim(),
        whatsapp: String(whatsapp).trim(),
        active: String(status).toUpperCase() === 'TRUE' || status === true,
        dataFinal: String(dataFinal).trim(),
        tempo: parseInt(String(tempo)) || 0
      };
    });
  } catch (error) {
    console.error('Error fetching data from Google Sheets:', error);
    throw error;
  }
}