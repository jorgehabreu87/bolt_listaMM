import React from 'react';
import { ArrowUpDown } from 'lucide-react';

interface SortButtonProps {
  onSort: () => void;
  isAscending: boolean;
}

export function SortButton({ onSort, isAscending }: SortButtonProps) {
  return (
    <button
      onClick={onSort}
      className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
    >
      <ArrowUpDown className="h-4 w-4 mr-2" />
      Ordem {isAscending ? 'Crescente' : 'Decrescente'}
    </button>
  );
}