import React from 'react';
import { Calendar } from 'lucide-react';

interface CustomerDateProps {
  date: string;
}

export function CustomerDate({ date }: CustomerDateProps) {
  if (!date) {
    return null;
  }

  return (
    <div className="flex items-center">
      <Calendar className="h-4 w-4 mr-1" />
      <span>Data Final: {date}</span>
    </div>
  );
}