import React from 'react';
import { Check, X } from 'lucide-react';

interface CustomerStatusProps {
  active: boolean;
}

export function CustomerStatus({ active }: CustomerStatusProps) {
  if (active) {
    return (
      <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
        <Check className="h-4 w-4 mr-1" />
        Ativo
      </span>
    );
  }

  return (
    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">
      <X className="h-4 w-4 mr-1" />
      Inativo
    </span>
  );
}