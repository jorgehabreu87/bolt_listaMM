import React from 'react';
import { Phone, Check, X, Calendar } from 'lucide-react';
import { Customer } from '../types/Customer';
import { TimeDisplay } from './TimeDisplay';
import { formatDateToBR } from '../utils/dateUtils';
import { CustomerStatus } from './CustomerStatus';
import { CustomerDate } from './CustomerDate';

interface CustomerListProps {
  customers: Customer[];
}

export function CustomerList({ customers }: CustomerListProps) {
  return (
    <div className="grid gap-4">
      {customers.map((customer) => (
        <div
          key={customer.id}
          className="bg-white rounded-lg shadow-sm p-4"
        >
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <h3 className="font-medium text-gray-900">{customer.name}</h3>
              <div className="flex items-center text-gray-600 mt-1">
                <Phone className="h-4 w-4 mr-1" />
                <span>{customer.whatsapp}</span>
              </div>
              <div className="flex flex-wrap gap-4 mt-2 text-sm text-gray-600">
                <CustomerDate date={customer.dataFinal} />
                <TimeDisplay days={customer.tempo} />
              </div>
            </div>
            <CustomerStatus active={customer.active} />
          </div>
        </div>
      ))}
    </div>
  );
}