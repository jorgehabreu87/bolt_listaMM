import React from 'react';
import { ContactLinks } from './ContactLinks';
import { CONTACT_INFO } from '../config/constants';

export function Footer() {
  return (
    <footer className="mt-12 py-4 border-t border-gray-200">
      <div className="max-w-3xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center text-sm text-gray-500">
        <ContactLinks 
          spreadsheetUrl={CONTACT_INFO.SPREADSHEET_URL}
          whatsappNumber={CONTACT_INFO.WHATSAPP_NUMBER}
        />
        <div className="mt-4 sm:mt-0">
          Desenvolvido por Sr Jorge © 2024
        </div>
      </div>
    </footer>
  );
}