import React from 'react';
import { Clock } from 'lucide-react';
import { formatDays, getDaysColor } from '../utils/dateUtils';

interface TimeDisplayProps {
  days: number;
}

export function TimeDisplay({ days }: TimeDisplayProps) {
  return (
    <div className="flex items-center">
      <Clock className="h-4 w-4 mr-1" />
      <span className={`font-medium ${getDaysColor(days)}`}>
        {formatDays(days)}
      </span>
    </div>
  );
}