export const CONTACT_INFO = {
  SPREADSHEET_URL: 'https://docs.google.com/spreadsheets/d/1uwf5RY_BhDUQg71hOZg4bcW52V4ApQxm7bW5Rq9wqxM/edit?usp=sharing',
  WHATSAPP_NUMBER: '5533991129055',
};