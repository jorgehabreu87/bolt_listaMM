import { useState, useEffect } from 'react';
import { Customer } from '../types/Customer';
import { fetchCustomers } from '../services/sheetsService';

export function useCustomers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadCustomers = async () => {
      try {
        setLoading(true);
        const data = await fetchCustomers();
        setCustomers(data);
        setError(null);
      } catch (err) {
        setError('Erro ao carregar dados dos clientes');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    loadCustomers();
  }, []);

  return { customers, loading, error };
}