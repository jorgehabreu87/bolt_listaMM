import { useState, useMemo } from 'react';
import { Customer } from '../types/Customer';

export function useCustomerSort(customers: Customer[]) {
  const [sortByActive, setSortByActive] = useState(false);

  const sortedCustomers = useMemo(() => {
    if (!sortByActive) return customers;

    return [...customers].sort((a, b) => {
      if (a.active === b.active) return 0;
      return a.active ? -1 : 1;
    });
  }, [customers, sortByActive]);

  const toggleSort = () => {
    setSortByActive(!sortByActive);
  };

  return {
    sortedCustomers,
    toggleSort,
  };
}