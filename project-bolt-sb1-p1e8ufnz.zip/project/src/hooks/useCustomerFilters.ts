import { useState, useMemo } from 'react';
import { Customer } from '../types/Customer';
import { filterCustomers } from '../utils/customerFilters';
import { sortCustomers } from '../utils/customerSort';

export function useCustomerFilters(customers: Customer[]) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isAscending, setIsAscending] = useState(true);

  const filteredCustomers = useMemo(() => {
    const filtered = filterCustomers(customers, {
      searchTerm,
      statusFilter,
    });
    
    return sortCustomers(filtered, isAscending);
  }, [customers, searchTerm, statusFilter, isAscending]);

  const toggleSort = () => setIsAscending(!isAscending);

  return {
    searchTerm,
    setSearchTerm,
    statusFilter,
    setStatusFilter,
    isAscending,
    toggleSort,
    filteredCustomers,
  };
}