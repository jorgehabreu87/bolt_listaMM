import React from 'react';
import { Users } from 'lucide-react';
import { SearchBar } from './components/SearchBar';
import { CustomerList } from './components/CustomerList';
import { SortButton } from './components/SortButton';
import { StatusFilter } from './components/StatusFilter';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import { useCustomers } from './hooks/useCustomers';
import { useCustomerFilters } from './hooks/useCustomerFilters';

function App() {
  const { customers, loading, error } = useCustomers();
  const {
    searchTerm,
    setSearchTerm,
    statusFilter,
    setStatusFilter,
    isAscending,
    toggleSort,
    filteredCustomers,
  } = useCustomerFilters(customers);

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="max-w-3xl mx-auto px-4 py-8">
        <header className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-blue-600 mr-3" />
            <h1 className="text-2xl font-bold text-gray-900">Lista de Clientes</h1>
          </div>
        </header>
        
        <section className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <SearchBar 
                searchTerm={searchTerm} 
                onSearchChange={setSearchTerm} 
              />
            </div>
            <div className="flex gap-2">
              <StatusFilter
                selectedStatus={statusFilter}
                onStatusChange={setStatusFilter}
              />
              <SortButton 
                onSort={toggleSort}
                isAscending={isAscending}
              />
            </div>
          </div>
        </section>

        <section className="mt-6">
          {filteredCustomers.length > 0 ? (
            <CustomerList customers={filteredCustomers} />
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">Nenhum cliente encontrado</p>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

export default App;