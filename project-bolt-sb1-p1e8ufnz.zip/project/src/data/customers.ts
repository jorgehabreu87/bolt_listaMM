import { Customer } from '../types/Customer';

export const customers: Customer[] = [
  {
    id: 1,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 2,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 3,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 4,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 5,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 6,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 7,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 8,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 9,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 10,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 11,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 12,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 13,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 14,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  },
  {
    id: 15,
    name: 'ALINE APARECIDA ALVES LANDIM',
    whatsapp: '5533991129055',
    active: true,
    dataFinal: '2024-03-31',
    tempo: 30
  }
];