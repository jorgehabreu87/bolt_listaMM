export interface Customer {
  id: number;
  name: string;
  whatsapp: string;
  active: boolean;
}