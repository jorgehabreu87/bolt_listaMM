import React, { useState, useMemo } from 'react';
import { Users } from 'lucide-react';
import { SearchBar } from './components/SearchBar';
import { CustomerList } from './components/CustomerList';
import { customers } from './data/customers';

function App() {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCustomers = useMemo(() => {
    const search = searchTerm.toLowerCase();
    return customers.filter(
      (customer) =>
        customer.name.toLowerCase().includes(search) ||
        customer.whatsapp.includes(search)
    );
  }, [searchTerm]);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-blue-600 mr-3" />
            <h1 className="text-2xl font-bold text-gray-900">Lista de Clientes</h1>
          </div>
        </div>
        
        <div className="mb-6">
          <SearchBar 
            searchTerm={searchTerm} 
            onSearchChange={setSearchTerm} 
          />
        </div>

        {filteredCustomers.length > 0 ? (
          <CustomerList customers={filteredCustomers} />
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-500">Nenhum cliente encontrado</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;