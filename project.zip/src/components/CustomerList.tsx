import React from 'react';
import { Phone, Check, X } from 'lucide-react';
import { Customer } from '../types/Customer';

interface CustomerListProps {
  customers: Customer[];
}

export function CustomerList({ customers }: CustomerListProps) {
  return (
    <div className="grid gap-4">
      {customers.map((customer) => (
        <div
          key={customer.id}
          className="bg-white rounded-lg shadow-sm p-4 flex items-center justify-between"
        >
          <div className="flex-1">
            <h3 className="font-medium text-gray-900">{customer.name}</h3>
            <div className="flex items-center text-gray-600 mt-1">
              <Phone className="h-4 w-4 mr-1" />
              <span>{customer.whatsapp}</span>
            </div>
          </div>
          <div className="flex items-center">
            {customer.active ? (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                <Check className="h-4 w-4 mr-1" />
                Ativo
              </span>
            ) : (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">
                <X className="h-4 w-4 mr-1" />
                Inativo
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}