import { Customer } from '../types/Customer';

export const customers: Customer[] = [
  {
    id: 1,
    name: 'João Silva',
    whatsapp: '11999887766',
    active: true,
  },
  {
    id: 2,
    name: 'Maria Santos',
    whatsapp: '11988776655',
    active: true,
  },
  {
    id: 3,
    name: 'Pedro Oliveira',
    whatsapp: '11977665544',
    active: false,
  },
  {
    id: 4,
    name: 'Ana Costa',
    whatsapp: '11966554433',
    active: true,
  },
  {
    id: 5,
    name: 'Carlos Ferreira',
    whatsapp: '11955443322',
    active: false,
  },
];